package projeto;

public class Time {
    private String nomeT;
    private int codigo;
    private Jogador jogadores;
    private int numDeJogadores;
    

    Time(int parseInt) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public String getNomeTime(){
        return nomeT;
    }

    public void setJogadores(Jogador jogadores) {
        this.jogadores = jogadores;
    }

    public int setNumDeJogadores(int numDeJogadores) {
        this.numDeJogadores = numDeJogadores;
        return 0;
       
    }

    public int getCodigo() {
        return codigo;
    }

    public Jogador getJogadores() {
        return jogadores;
    }

    public int getNumDeJogadores() {
        return numDeJogadores;
    }

    public Time(int codigo,String nomeT,int numDeJogadores) {
        this.codigo = codigo;
        this.nomeT = nomeT;
        this.numDeJogadores = numDeJogadores;
    }
    
}
