package projeto;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TelaTime extends javax.swing.JFrame {

    ControlaTime ct;

    public TelaTime() {
        initComponents();
    }
    
    public TelaTime(ControlaTime ct){
        initComponents();
        this.ct = ct;
         DefaultTableModel tabTimes = (DefaultTableModel) tabelaTimes.getModel();
            while (tabTimes.getRowCount()>0){
                tabTimes.removeRow(0);

            }
            List<Time> lista = new ArrayList<>();
            lista = ct.retornaTodosT();
            for(Time ListaTime : lista){
                Object[] Time = new Object[]{
                    ListaTime.getCodigo(),
                    ListaTime.getNomeTime(),
                    ListaTime.getNumDeJogadores()
                };
               tabTimes.addRow(Time);
            }
            txtCodigoTime.setText("");
            txtNomeTime.setText("");
            txtNumJogadorTime.setText("");
            txtCodigoTime.setEditable(true);
            txtNomeTime.setEditable(false);
            txtNumJogadorTime.setEditable(false);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtCodigoTime = new javax.swing.JTextField();
        txtNomeTime = new javax.swing.JTextField();
        txtNumJogadorTime = new javax.swing.JTextField();
        btnPesquisarTime = new javax.swing.JButton();
        btnSalvarTime = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaTimes = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        btnExcluir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Tela de Inscricao de Times");

        jLabel2.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel2.setText("Codigo");

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel4.setText("Nome");

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel5.setText("Numero de Jogadores");

        txtCodigoTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodigoTimeActionPerformed(evt);
            }
        });

        btnPesquisarTime.setText("Pesquisar");
        btnPesquisarTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarTimeActionPerformed(evt);
            }
        });

        btnSalvarTime.setText("Salvar");
        btnSalvarTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarTimeActionPerformed(evt);
            }
        });

        tabelaTimes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Codigo", "Nome", "Numero de Jogadores"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabelaTimes);

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtNumJogadorTime, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnPesquisarTime))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 601, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtNomeTime))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtCodigoTime, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnExcluir)
                                .addGap(35, 35, 35)
                                .addComponent(btnSalvarTime)))
                        .addGap(384, 384, 384))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtCodigoTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSalvarTime)
                    .addComponent(btnExcluir))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtNomeTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtNumJogadorTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPesquisarTime))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addGap(46, 46, 46)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(260, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtCodigoTimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodigoTimeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodigoTimeActionPerformed

    private void btnPesquisarTimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarTimeActionPerformed
        Time t = ct.pesquisaTime(Integer.parseInt(txtCodigoTime.getText()));
        txtCodigoTime.setEditable(true);
        txtNomeTime.setEditable(true);
        txtNumJogadorTime.setEditable(true);
        
        if (t == null){
            txtCodigoTime.setText("");
            txtNomeTime.setText("");
            txtNumJogadorTime.setText("");
        }
        else{
            txtCodigoTime.setText(String.valueOf(t.getCodigo()));
            txtNomeTime.setText(t.getNomeTime());
            txtNumJogadorTime.setText(String.valueOf(t.getNumDeJogadores()));
            
            
}
    }//GEN-LAST:event_btnPesquisarTimeActionPerformed

    private void btnSalvarTimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarTimeActionPerformed
        try{
            Time t = new Time(
                    Integer.parseInt(txtCodigoTime.getText()),
                    txtNomeTime.getText(),
                    Integer.parseInt(txtNumJogadorTime.getText()));
                    
         
            
            if (ct.salvaTime(t)){
                
                JOptionPane.showMessageDialog(
                this,
                "Time salvo com sucesso");
            }
            
            else{
                JOptionPane.showMessageDialog(
                this, 
                "Ocorreu um erro com os dados",
                "Mensagem de erro",
                JOptionPane.ERROR_MESSAGE);
            }
            DefaultTableModel tabTimes = (DefaultTableModel) tabelaTimes.getModel();
            while (tabTimes.getRowCount()>0){
                tabTimes.removeRow(0);

            }
            List<Time> lista = new ArrayList<>();
            lista = ct.retornaTodosT();
            for(Time ListaTime : lista){
                Object[] Time = new Object[]{
                    ListaTime.getCodigo(),
                    ListaTime.getNomeTime(),
                    ListaTime.getNumDeJogadores()
                };
               tabTimes.addRow(Time);
            }
            txtCodigoTime.setText("");
            txtNomeTime.setText("");
            txtNumJogadorTime.setText("");
            txtCodigoTime.setEditable(true);
            txtNomeTime.setEditable(false);
            txtNumJogadorTime.setEditable(false);
        }
        catch (Exception erro){
            JOptionPane.showMessageDialog(this,
                    "Algo está incorreto", 
                    "Mensagem de erro",
                    JOptionPane.ERROR_MESSAGE);
                   
        }
    }//GEN-LAST:event_btnSalvarTimeActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
         int linha = tabelaTimes.getSelectedRow();
    if (linha == -1) {
        JOptionPane.showMessageDialog(
            this,
            "Nenhum time foi selecionado",
            "Mensagem de erro",
            JOptionPane.ERROR_MESSAGE);
    } else {
        int confirma = JOptionPane.showConfirmDialog(
            this, "Confirma a exclusão do time selecionado ?");
        if (confirma == 0) {
            int codigo = Integer.parseInt(tabelaTimes.getValueAt(linha, 0).toString());
            
            
            Time timeExcluir = ct.pesquisaTime(codigo);

            if (timeExcluir != null) {
                
                boolean sucessoExclusao = ct.excluiTime(timeExcluir);

                if (sucessoExclusao) {
                    JOptionPane.showMessageDialog(
                        this,
                        "Time excluído com sucesso");

                    
                    atualizarTabelaTimes();
                } else {
                    JOptionPane.showMessageDialog(
                        this,
                        "Ocorreu um erro ao excluir o time",
                        "Mensagem de erro",
                        JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(
                    this,
                    "Time não encontrado",
                    "Mensagem de erro",
                    JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void atualizarTabelaTimes() {
    DefaultTableModel tabTimes = (DefaultTableModel) tabelaTimes.getModel();
    tabTimes.setRowCount(0); 

    List<Time> lista = ct.retornaTodosT();
    for (Time time : lista) {
        Object[] linha = new Object[]{
            time.getCodigo(),
            time.getNomeTime(),
            time.getNumDeJogadores()
        };
        tabTimes.addRow(linha);
    }
}
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaTime.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaTime.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaTime.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaTime.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaTime().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnPesquisarTime;
    private javax.swing.JButton btnSalvarTime;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelaTimes;
    private javax.swing.JTextField txtCodigoTime;
    private javax.swing.JTextField txtNomeTime;
    private javax.swing.JTextField txtNumJogadorTime;
    // End of variables declaration//GEN-END:variables
}
