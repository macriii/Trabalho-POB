
package projeto;

import java.util.ArrayList;
import java.util.List;


public class ControlaJogador {
    private List<Jogador> listaJogadores;

    public ControlaJogador() {
        this.listaJogadores = new ArrayList<>();
    }
     private boolean existeJogador(int codigo){
        for ( Jogador j : this.listaJogadores){
            if (j.getCodigo() == codigo){
                return true;
            }
        }  
         return false;
    } 
     
     public Jogador pesquisaJogador ( int codigo){
        for (Jogador j : this.listaJogadores){
            if (j.getCodigo()== codigo){
                return j;
            }
        }
        return null;
    }
     
     public int retornarIndice (int codigo){
        for (Jogador j : this.listaJogadores){
            if (j.getCodigo() == codigo){
                return this.listaJogadores.indexOf(j);
            }
        }
        return -1;
    }
     
     public boolean salvaJogador(Jogador j){
        if (j == null){
            return false;
        }
        if (existeJogador(j.getCodigo())){
            this.listaJogadores.set(retornarIndice(j.getCodigo()),j );
                    return true;
        }
        else{
            this.listaJogadores.add(j);
            return true;
        }
    }
     
     public boolean excluirJogador(Jogador j){
        if (j == null){
            return false;
        }
        if (existeJogador(j.getCodigo())){
            this.listaJogadores.remove(retornarIndice(j.getCodigo()));
            return true;
        }
        else 
            return false;
    }
     
     public List<Jogador> retornarTodos(){
         return this.listaJogadores;
     }
}
