/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto;

import java.util.Date;



/**
 *
 * @author IFSP
 */
public class Jogador {
   

    public int getCodigo() {
        return codigo;
    }
    

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    private int codigo;
    private int numCamisa;
    private String nome;
    private double altura;
    private String posicao;
    private Date dataNasc;

    public void setNumCamisa(int numCamisa) {
        this.numCamisa = numCamisa;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public void setPosicao(String posicao) {
        this.posicao = posicao;
    }

    public void setDataNasc(Date dataNasc) {
        this.dataNasc = dataNasc;
    }

    public int getNumCamisa() {
        return numCamisa;
    }

    public String getNome() {
        return nome;
    }

    public double getAltura() {
        return altura;
    }

    public String getPosicao() {
        return posicao;
    }

    public Date getDataNasc() {
        return dataNasc;
    }

    public Jogador(int numCamisa,int codigo, String nome, double altura, String posicao, Date dataNasc) {
        this.numCamisa = numCamisa;
        this.codigo = codigo;
        this.nome = nome;
        this.altura = altura;
        this.posicao = posicao;
        this.dataNasc = dataNasc;
    }
    
}
