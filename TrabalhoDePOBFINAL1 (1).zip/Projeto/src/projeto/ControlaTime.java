
package projeto;

import java.util.ArrayList;
import java.util.List;

public class ControlaTime {
    private List<Time>ListaTime;
    
    public ControlaTime(){
        this.ListaTime = new ArrayList<>();  
    }
    
    private boolean existeTime(int codigo){
        for (Time t : this.ListaTime){
            if(t.getCodigo()== codigo){
                return true;
            }
        }
        return false;
    }
    
    public Time pesquisaTime (int codigo){
        for(Time t : this.ListaTime){
            if (t.getCodigo() == codigo){
                return t;
            }
        }
        return null;
    }
    public int retornaIndiceT(int codigo){
        for (Time t : this.ListaTime){
            if (t.getCodigo() == codigo){
                return this.ListaTime.indexOf(t);
            }
        }
        return -1;
    }
    
    public boolean salvaTime(Time t){
        if (t == null){
            return false;
        }
        if (existeTime(t.getCodigo())){
            this.ListaTime.set(retornaIndiceT(t.getCodigo()),t);
            return true;
        }
        else{
            this.ListaTime.add(t);
            return true;
        }
    }
    
    public boolean excluiTime(Time t){
        if(t == null){
            return false;            
    }
        if (existeTime(t.getCodigo())){
            this.ListaTime.remove(retornaIndiceT(t.getCodigo()));
            return true;
        }
        else
            return true;
    }
    
    public List<Time>retornaTodosT(){
        return this.ListaTime;
    }
                    
}
